<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sehatqu Apotik Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #95dafa;">
    <?php echo $__env->make('user.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="text-center">Dokter</h1>
    <div class="container" style="display: flex; justify-content: space-around; padding: 5px;">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card"
                style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); width: 500px; transition: transform 0.3s ease-in-out;">
                <div class="card-header"
                    style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 5px;">
                    <div class="name" style="font-size: 18px; font-weight: bold;"><?php echo e($item->nama_dokter); ?></div>
                    <div class="status" style="display: flex; align-items: center;">
                        <i class="fas fa-user-md" style="margin-right: 5px;"></i>
                        <span>Spesialis <?php echo e($item->spesialis); ?></span>
                    </div>
                </div>
                <div class="card-body text-center" style="margin-bottom: 20px;">
                    <img src="<?php echo e(asset('img/dokter')); ?>/<?php echo e($item->gambar); ?>" alt="Doctor image" class="doctor-image"
                        style="width: 150px; height: 150px; border-radius: 50%; margin-right: 20px; transition: transform 0.3s ease-in-out;">
                    <p style="margin: 0; padding: 10px;"><?php echo e($item->deskripsi); ?></p>
                    <div class="info"
                        style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                        <div><i class="far fa-clock"></i> 35 tahun</div>
                        <div><i class="fas fa-thumbs-up"></i> 99%</div>
                    </div>
                </div>
                <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
                    <button onclick="location.href='<?php echo e(url('/konsultasi')); ?>'"
                        style="background-color: #ff5733; color: #fff; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease-in-out;">Konsultasi</button>
                    <span class="price" style="font-size: 18px; font-weight: bold;">Rp.
                        <?php echo e($item->harga_konsultasi); ?></span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </div>
    

</html>
<?php /**PATH D:\FASTY_FOOD\sehattq\resources\views/user/dokter/dokter.blade.php ENDPATH**/ ?>